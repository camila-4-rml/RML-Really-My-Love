# RML — Really My Love

Versión estática inicial generada a partir de la exportación XML de WordPress.

Archivos principales:
- index.html
- catalogo.html
- nosotros.html
- contacto.html
- style.css

El XML original se conserva como respaldo.
